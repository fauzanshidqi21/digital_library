<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.headers.cards', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="<?php echo e(asset('jquery')); ?>/dist/jquery.min.js"></script>
    <script>
        $(document).ready(function(){
            $("#myInput").on("keyup", function() {
                var value = $(this).val().toLowerCase();
                $("#myTable tr").filter(function() {
                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                });
            });
        });
    </script>

    <div class="container-fluid mt--7">
        <div class="row">
            <div class="col">
                <div class="card shadow">
                    <div class="card-header border-0">
                        <div class="row align-items-center">
                            <div class="col-8">
                                <h3 class="mb-0">Bibliografi</h3>
                            </div>
                            <div class="col-4 text-right">
                                <a href="/bibliografi/book/create" class="btn btn-sm btn-primary"><?php echo e(__('Add Buku')); ?></a>
                            </div>
                        </div>
                    </div>

                    <div class="card-header border-0">
                        <div class="row align-items-center">
                            <div class="col-lg-12 mb-4">
                                
                                <li class="nav-item dropdown py-1 px-2" style="list-style-position:inside; border: 1px solid #5e72e4; border-radius: 5px; font-size:13px;">
                                    <a href="#insurance-head-section" class="nav-link dropdown-toggle" data-toggle="dropdown" style="color:#5e72e4"><i class="fas fa-file-export pr-2"></i>EXPORT</a>
                                    <div class="dropdown-menu">
                                        <a href="" class="dropdown-item" data-toggle="modal" data-target="#export-bulan">Export Per-Bulan</a>
                                        <div class="dropdown-divider"></div>
                                        <a href="" class="dropdown-item" data-toggle="modal" data-target="#export-tahun">Export Per-Tahun</a>
                                    </div>
                                    </li>
                                </ul>
                                        
                                        
                                
                                <div class="modal fade" id="export-bulan" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLabel">Export Excel Per-Bulan</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>

                                            <div>
                                                <form action="/bibliografi/book/export/view" method="POST">
                                                    <?php echo csrf_field(); ?>

                                                    <div class="modal-body">
                                                        
                                                        <?php
                                                            $i = 1;
                                                        ?>
                                                        <div class="pb-4">
                                                            <label class="form-control-label" for="input-harga"><?php echo e(__('Bulan')); ?></label>
                                                            <select class="form-control" name="bulan" id="bulan">
                                                                <?php $__currentLoopData = $month; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mnth): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($i++); ?>"><?php echo e($mnth); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>

                                                        
                                                        <div>
                                                            <label class="form-control-label" for="input-harga"><?php echo e(__('Tahun')); ?></label>
                                                            <select class="form-control" name="tahun" id="tahun">
                                                                <?php for($year = 1900; $year <= 2019; $year++): ?>
                                                                    <?php if($year === 2019): ?>
                                                                        <option value="<?php echo e($year); ?>" selected><?php echo e($year); ?></option>  
                                                                    <?php else: ?>
                                                                        <option value="<?php echo e($year); ?>"><?php echo e($year); ?></option>  
                                                                    <?php endif; ?>
                                                                <?php endfor; ?>
                                                            </select>
                                                        </div>

                                                    </div>

                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                        <button type="submit" class="btn btn-primary">View Export</button>
                                                    </div>
                                                </form>
                                            </div>

                                        </div>
                                    </div>
                                </div>

                                
                                <div class="modal fade" id="export-tahun" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLabel">Export Excel Per-Tahun</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>

                                            <div>
                                                <form action="/bibliografi/book/export/view" method="POST">
                                                    <?php echo csrf_field(); ?>

                                                    <div class="modal-body">
                                                        
                                                        <div>
                                                            <label class="form-control-label" for="input-harga"><?php echo e(__('Tahun')); ?></label>
                                                            <select class="form-control" name="tahun" id="tahun">
                                                                <?php for($year = 1900; $year <= 2019; $year++): ?>
                                                                    <?php if($year === 2019): ?>
                                                                        <option value="<?php echo e($year); ?>" selected><?php echo e($year); ?></option>  
                                                                    <?php else: ?>
                                                                        <option value="<?php echo e($year); ?>"><?php echo e($year); ?></option>  
                                                                    <?php endif; ?>
                                                                <?php endfor; ?>
                                                            </select>
                                                        </div>

                                                    </div>

                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                        <button type="submit" class="btn btn-primary">View Export</button>
                                                    </div>
                                                </form>
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                                
                                
                                <button class="btn btn-sm btn-outline-primary py-2 px-3 ml-3" type="button" data-toggle="modal" data-target="#importExcel"><i class="fas fa-file-import pr-2"></i>IMPORT</button>
                                
                               
                                

                                
                                <div class="modal fade importExcel" id="importExcel" tabindex="-1" role="dialog" aria-labelledby="importExcel" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <form method="post" action="/bibliografi/book/import/excel" enctype="multipart/form-data">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">Import Excel</h5>
                                                </div>
                                                <div class="modal-body">
                                                    <?php echo csrf_field(); ?>
                        
                                                    <label>Pilih file excel</label>
                                                    <div class="form-group">
                                                        <input type="file" name="file" required="required">
                                                    </div>

                                                    <label class="mr-3 pt-3">atau download contoh file import</label>
                                                    <a href="/bibliografi/book/download/example-excel">
                                                        <i class="fas fa-download mr-1"></i>
                                                        Download
                                                    </a>
                        
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                    <button type="submit" class="btn btn-primary">Import</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
        
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <div class="input-group input-group-alternative mb-4">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="ni ni-zoom-split-in"></i></span>
                                    </div>
                                    <input id="myInput" class="form-control form-control-alternative" placeholder="Search" type="text">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-12">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <?php echo e(session('status')); ?>

                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="table-responsive">
                        <table class="table align-items-center table-flush">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col"><?php echo e(__('No.')); ?></th>
                                    <th scope="col"><?php echo e(__('Judul')); ?></th>
                                    <th scope="col"><?php echo e(__('ISBN')); ?></th>
                                    <th scope="col"><?php echo e(__('Pengarang')); ?></th>
                                    <th scope="col"><?php echo e(__('Penerbit')); ?></th>
                                    <th scope="col"><?php echo e(__('Tahun Terbit')); ?></th>
                                    <th scope="col"><?php echo e(__('Jumlah Buku')); ?></th>
                                    <th scope="col"><?php echo e(__('Lokasi')); ?></th>
                                    <th scope="col"><?php echo e(__('Publisher')); ?></th>
                                    <th scope="col"><?php echo e(__('Data File Digital')); ?></th>

                                    <?php if(auth()->user()->level != 3): ?>
                                        <th scope="col"><?php echo e(__('Action')); ?></th>    
                                    <?php else: ?>
                                        <th scope="col"></th> 
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody id="myTable">
                            <?php
                                $i = 1;
                            ?>
                            <?php $__currentLoopData = $bibli; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($double !== $data->buku_id): ?>
                                    <tr>
                                        <td><?php echo e($i++); ?></td>
                                        <td><?php echo e($data->judul); ?> <?php echo e($data->anak_judul); ?></td>
                                        <td><?php echo e($data->isbn); ?></td>
                                        <td>
                                            <?php $__currentLoopData = $authorBook; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($data->buku_id == $ab->buku_id): ?>
                                                    <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ath): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($ab->authors_id == $ath->id): ?>
                                                            <?php echo e($ath->name); ?><br> 
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                        <td><?php echo e($data->penerbit); ?></td>
                                        <td><?php echo e($data->tahun_terbit); ?></td>
                                        <td><?php echo e($data->jumlah_buku); ?></td>
                                        <td><?php echo e($data->lokasi); ?></td>
                                        <td>
                                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($user->id == $data->publisher_id): ?>
                                                    <?php echo e($user->name); ?>

                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                        <?php if($data->file == null): ?>
                                             <td><?php echo e(0); ?></td>
                                         <?php else: ?>
                                             <td><?php echo e(1); ?></td>
                                         <?php endif; ?>
     
                                        <td class="text-right">
                                            <div class="row">
                                                <div class="">
                                                    <div class="d-flex justify-content-between align-items-baseline">
                                                        <?php if(auth()->user()->level != 3): ?>
     
                                                            <div class="dropdown">
                                                                <a class="btn btn-sm btn-icon-only text-light" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                    <i class="fas fa-ellipsis-v"></i>
                                                                </a>
                                                                <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                                                     <form action="/bibliografi/book/<?php echo e($data->bibliografi_id); ?>" method="post">
                                                                         <?php echo csrf_field(); ?>
                                                                         <?php echo method_field('delete'); ?>
                                                                         
                                                                         <a class="dropdown-item" href="/bibliografi/book/edit/<?php echo e($data->bibliografi_id); ?>"><?php echo e(__('Edit')); ?></a>
                                                                         <button type="button" class="dropdown-item" onclick="confirm('<?php echo e(__("Are you sure you want to delete this book data?")); ?>') ? this.parentElement.submit() : '' ">
                                                                             <?php echo e(__('Delete')); ?>

                                                                         </button>
                                                                     </form>
                                                                </div>
                                                            </div>
                                                        <?php endif; ?>
                                                    </div>      
                                                </div>
                                            </div>                                           
                                        </td>
                                    </tr>
                                    <?php
                                        $double = $data->buku_id
                                    ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              
                            </tbody>
                        </table>                            
                    </div>

                    <div class="card-footer py-4">
                        <nav class="d-flex justify-content-end" aria-label="...">
                            <?php echo e($bibli->links()); ?>

                        </nav>
                    </div>
                </div>
            </div>
        </div>
            
        <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <script>
        
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['title' => __('User Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\repolib\resources\views/bibliografi/books/index.blade.php ENDPATH**/ ?>