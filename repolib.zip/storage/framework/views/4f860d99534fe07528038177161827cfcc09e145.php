<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.headers.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container mt--8 pb-5">
        <!-- Table -->
        <div class="row justify-content-center">
            <div class="col-lg-6 col-md-8">
                <div class="card bg-secondary shadow border-0">
                    <div class="card-body px-lg-5 py-lg-5">
                        <div class="text-center text-muted mb-5">
                            <h2>REGISTER NEW ACCOUNT</h2>
                        </div>
                        <form role="form" method="POST" action="<?php echo e(route('register')); ?>">
                            <?php echo csrf_field(); ?>
                            
                            <div class="form-group<?php echo e($errors->has('name') ? ' has-danger' : ''); ?>">
                                <div class="input-group input-group-alternative mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="ni ni-hat-3"></i></span>
                                    </div>
                                    <input class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" placeholder="<?php echo app('translator')->getFromJson('form.name'); ?>" type="text" name="name" value="<?php echo e(old('name')); ?>" required autofocus>
                                </div>
                                <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback" style="display: block;" role="alert">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>

                            
                            <div class="form-group<?php echo e($errors->has('email') ? ' has-danger' : ''); ?>">
                                <div class="input-group input-group-alternative mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="ni ni-email-83"></i></span>
                                    </div>
                                    <input class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" placeholder="<?php echo app('translator')->getFromJson('form.email'); ?>" type="email" name="email" value="<?php echo e(old('email')); ?>" required>
                                </div>
                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" style="display: block;" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>

                            
                            <div class="form-group<?php echo e($errors->has('password') ? ' has-danger' : ''); ?>">
                                <div class="input-group input-group-alternative">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="ni ni-lock-circle-open"></i></span>
                                    </div>
                                    <input class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" placeholder="<?php echo app('translator')->getFromJson('form.password'); ?>" type="password" name="password" required>
                                </div>
                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback" style="display: block;" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>

                            
                            <div class="form-group">
                                <div class="input-group input-group-alternative">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="ni ni-lock-circle-open"></i></span>
                                    </div>
                                    <input class="form-control" placeholder="<?php echo app('translator')->getFromJson('form.confirm_password'); ?>" type="password" name="password_confirmation" required>
                                </div>
                            </div>

                            
                            <div class="form-group<?php echo e($errors->has('kode') ? ' has-danger' : ''); ?>">
                                <div class="input-group input-group-alternative mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="fas fa-id-card"></i></span>
                                    </div>
                                    <input class="form-control<?php echo e($errors->has('kode') ? ' is-invalid' : ''); ?>" placeholder="<?php echo app('translator')->getFromJson('form.user_id'); ?>" type="text" name="kode" value="<?php echo e(old('kode')); ?>" required autofocus>
                                </div>
                                <?php if($errors->has('kode')): ?>
                                    <span class="invalid-feedback" style="display: block;" role="alert">
                                        <strong><?php echo e($errors->first('kode')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>

                            
                            <div class="form-group<?php echo e($errors->has('alamat') ? ' has-danger' : ''); ?>">
                                <div class="input-group input-group-alternative mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="ni ni-square-pin"></i></span>
                                    </div>
                                    <input class="form-control<?php echo e($errors->has('alamat') ? ' is-invalid' : ''); ?>" placeholder="<?php echo app('translator')->getFromJson('form.address'); ?>" type="text" name="alamat" value="<?php echo e(old('alamat')); ?>" required autofocus>
                                </div>
                                <?php if($errors->has('alamat')): ?>
                                    <span class="invalid-feedback" style="display: block;" role="alert">
                                        <strong><?php echo e($errors->first('alamat')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>

                            
                            <div class="form-group<?php echo e($errors->has('provinsi') ? ' has-danger' : ''); ?>">
                                <div class="input-group input-group-alternative mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="fas fa-city"></i></span>
                                    </div>
                                    <input class="form-control<?php echo e($errors->has('provinsi') ? ' is-invalid' : ''); ?>" placeholder="<?php echo app('translator')->getFromJson('form.province'); ?>" type="text" name="provinsi" value="<?php echo e(old('provinsi')); ?>" required autofocus>
                                </div>
                                <?php if($errors->has('provinsi')): ?>
                                    <span class="invalid-feedback" style="display: block;" role="alert">
                                        <strong><?php echo e($errors->first('provinsi')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>

                            
                            <div class="form-group<?php echo e($errors->has('kode_pos') ? ' has-danger' : ''); ?>">
                                <div class="input-group input-group-alternative mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="fas fa-map-pin"></i></span>
                                    </div>
                                    <input class="form-control<?php echo e($errors->has('kode_pos') ? ' is-invalid' : ''); ?>" placeholder="<?php echo app('translator')->getFromJson('form.postal_code'); ?>" type="text" name="kode_pos" value="<?php echo e(old('kode_pos')); ?>" required autofocus>
                                </div>
                                <?php if($errors->has('kode_pos')): ?>
                                    <span class="invalid-feedback" style="display: block;" role="alert">
                                        <strong><?php echo e('Postal code must be a number'); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>

                            
                            <?php
                                $warga_negara = ['WNI', 'WNA'];
                            ?>
                            <label class="form-control-label pt-3"><?php echo e(__('Warga Negara')); ?></label>
                            <div class="form-group<?php echo e($errors->has('warga_negara') ? ' has-danger' : ''); ?>">
                                <div class="row">
                                <?php $__currentLoopData = $warga_negara; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-12">
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="warga_negara" id="warga_negara" value="<?php echo e($wn); ?>" required>
                                        <label class="form-check-label" style="text-transform:capitalize"><?php echo e($wn); ?></label>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>

                                <?php if($errors->has('warga_negara')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('warga_negara')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>

                            
                            <?php
                                $jenis_kelamin = ['Laki-Laki', 'Perempuan', 'Lainnya'];
                            ?>
                            <label class="form-control-label pt-3"><?php echo e(__('Jenis Kelamin')); ?></label>
                            <div class="form-group<?php echo e($errors->has('jenis_kelamin') ? ' has-danger' : ''); ?>">
                                <div class="row">
                                <?php $__currentLoopData = $jenis_kelamin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-12">
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="jenis_kelamin" id="jenis_kelamin" value="<?php echo e($jk); ?>" required>
                                        <label class="form-check-label" style="text-transform:capitalize"><?php echo e($jk); ?></label>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>

                                <?php if($errors->has('jenis_kelamin')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('jenis_kelamin')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>

                            
                            <div class="row my-4">
                                    <div class="col-12">
                                        <div class="custom-control custom-control-alternative custom-checkbox">
                                            <input class="custom-control-input" id="customCheckRegister" type="checkbox">
                                            <label class="custom-control-label" for="customCheckRegister">
                                                <span class="text-muted"><?php echo e(__('I agree with the')); ?> <a href="#!"><?php echo e(__('Privacy Policy')); ?></a></span>
                                            </label>
                                        </div>
                                    </div>
                                </div>

                            <div class="text-center">
                                <button type="submit" class="btn btn-primary mt-4"><?php echo e(__('Create account')); ?></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript" src="<?php echo e(asset('argon')); ?>/vendor/jquery/dist/jquery.min.js"></script>
    <link href="<?php echo e(asset('select2')); ?>/dist/css/select2.min.css" rel="stylesheet"/>
    <script src="<?php echo e(asset('select2')); ?>/dist/js/select2.min.js"></script>
    <script>
        $('#warga_negara').select2({
                placeholder: "Warga Negara",
                allowClear: true
            });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['class' => 'bg-default'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\repolib\resources\views/auth/register.blade.php ENDPATH**/ ?>