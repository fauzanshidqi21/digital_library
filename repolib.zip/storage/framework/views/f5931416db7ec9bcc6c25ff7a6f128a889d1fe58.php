<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.headers.cards', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="<?php echo e(asset('jquery')); ?>/dist/jquery.min.js"></script>
    <script>
        $(document).ready(function(){
            $("#myInput").on("keyup", function() {
                var value = $(this).val().toLowerCase();
                $("#myTable tr").filter(function() {
                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                });
            });
        });
    </script>

    <div class="container-fluid mt--7">
        <div class="row">
            <div class="col">
                <div class="card shadow">
                    <div class="card-header border-0">
                        <div class="row align-items-center">
                            <div class="col-8">
                                <h3 class="mb-0">Buku Tamu</h3>
                            </div>
                        </div>
                    </div>

                    <div class="card-header border-0">
                        <div class="row align-items-center">
                            <div class="col-lg-12 mb-4">
                                
                                <li class="nav-item dropdown py-1 px-2" style="list-style-position:inside; border: 1px solid #5e72e4; border-radius: 5px; font-size:13px;">
                                    <a href="#insurance-head-section" class="nav-link dropdown-toggle" data-toggle="dropdown" style="color:#5e72e4"><i class="fas fa-file-export pr-2"></i>EXPORT</a>
                                    <div class="dropdown-menu">
                                        <a href="" class="dropdown-item" data-toggle="modal" data-target="#export-bulan">Export Per-Bulan</a>
                                        <div class="dropdown-divider"></div>
                                        <a href="" class="dropdown-item" data-toggle="modal" data-target="#export-tahun">Export Per-Tahun</a>
                                    </div>
                                    </li>
                                </ul>
                                        
                                        
                                
                                <div class="modal fade" id="export-bulan" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLabel">Export Excel Per-Bulan</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>

                                            <div>
                                                <form action="/guestbook-all-data/export/view" method="POST">
                                                    <?php echo csrf_field(); ?>

                                                    <div class="modal-body">
                                                        
                                                        <?php
                                                            $i = 1;
                                                        ?>
                                                        <div class="pb-4">
                                                            <label class="form-control-label" for="input-harga"><?php echo e(__('Bulan')); ?></label>
                                                            <select class="form-control" name="bulan" id="bulan">
                                                                <?php $__currentLoopData = $month; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mnth): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($i++); ?>"><?php echo e($mnth); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>

                                                        
                                                        <div>
                                                            <label class="form-control-label" for="input-harga"><?php echo e(__('Tahun')); ?></label>
                                                            <select class="form-control" name="tahun" id="tahun">
                                                                <?php for($year = 1900; $year <= 2019; $year++): ?>
                                                                    <?php if($year === 2019): ?>
                                                                        <option value="<?php echo e($year); ?>" selected><?php echo e($year); ?></option>  
                                                                    <?php else: ?>
                                                                        <option value="<?php echo e($year); ?>"><?php echo e($year); ?></option>  
                                                                    <?php endif; ?>
                                                                <?php endfor; ?>
                                                            </select>
                                                        </div>

                                                    </div>

                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                        <button type="submit" class="btn btn-primary">View Export</button>
                                                    </div>
                                                </form>
                                            </div>

                                        </div>
                                    </div>
                                </div>

                                
                                <div class="modal fade" id="export-tahun" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLabel">Export Excel Per-Tahun</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>

                                            <div>
                                                <form action="/guestbook-all-data/export/view" method="POST">
                                                    <?php echo csrf_field(); ?>

                                                    <div class="modal-body">
                                                        
                                                        <div>
                                                            <label class="form-control-label" for="input-harga"><?php echo e(__('Tahun')); ?></label>
                                                            <select class="form-control" name="tahun" id="tahun">
                                                                <?php for($year = 1900; $year <= 2019; $year++): ?>
                                                                    <?php if($year === 2019): ?>
                                                                        <option value="<?php echo e($year); ?>" selected><?php echo e($year); ?></option>  
                                                                    <?php else: ?>
                                                                        <option value="<?php echo e($year); ?>"><?php echo e($year); ?></option>  
                                                                    <?php endif; ?>
                                                                <?php endfor; ?>
                                                            </select>
                                                        </div>

                                                    </div>

                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                        <button type="submit" class="btn btn-primary">View Export</button>
                                                    </div>
                                                </form>
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
        
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <div class="input-group input-group-alternative mb-4">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="ni ni-zoom-split-in"></i></span>
                                    </div>
                                    <input id="myInput" class="form-control form-control-alternative" placeholder="Search" type="text">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-12">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <?php echo e(session('status')); ?>

                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="table-responsive">
                        <table class="table align-items-center table-flush">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col"><?php echo e(__('No.')); ?></th>
                                    <th scope="col"><?php echo e(__('Kode')); ?></th>
                                    <th scope="col"><?php echo e(__('Status')); ?></th>
                                    <th scope="col"><?php echo e(__('Nama')); ?></th>
                                    <th scope="col"><?php echo e(__('Alamat')); ?></th>
                                    <th scope="col"><?php echo e(__('Pekerjaan')); ?></th>
                                    <th scope="col"><?php echo e(__('Pendidikan')); ?></th>
                                    <th scope="col"><?php echo e(__('Jenis Kelamin')); ?></th>
                                    <th scope="col"><?php echo e(__('Action')); ?></th>
                                </tr>
                            </thead>
                            
                            <tbody id="myTable">
                            <?php
                                $i = 1;
                            ?>
                            <?php $__currentLoopData = $guest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i++); ?></td>
                                    <td><?php echo e($data->kode); ?></td>
                                    <td><?php echo e(ucfirst($data->status)); ?></td>
                                    <td><?php echo e(ucfirst($data->nama)); ?></td>
                                    <td><?php echo e(ucfirst($data->alamat)); ?></td>
                                    <td><?php echo e(ucfirst($data->pekerjaan ?? '-')); ?></td>
                                    <td><?php echo e(ucfirst($data->pendidikan ?? '-')); ?></td>
                                    <td><?php echo e(ucfirst($data->jenis_kelamin ?? '-')); ?></td>
                                    <td>
                                        <?php if($data->guest_id != null): ?>
                                            <button type="button" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#modal-group-<?php echo e($data->guest_id); ?>">Detail</button>
                                        <?php endif; ?>
                                    </td>
                                </tr>

                                
                                <div class="modal fade" id="modal-group-<?php echo e($data->guest_id); ?>" tabindex="-1" role="dialog" aria-labelledby="modal-group" aria-hidden="true">
                                    <div class="modal-dialog modal-danger modal-dialog-centered modal-" role="document">
                                        <div class="modal-content bg-gradient-danger">
                                            
                                            <div class="modal-header">
                                                <h6 class="modal-title" id="modal-title-group">Guestbook <?php echo e($data->kode); ?> Detail</h6>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">×</span>
                                                </button>
                                            </div>
                                            
                                            <div class="modal-body">
                                                
                                                <div class="py-3 text-left">
                                                    <h3 class="heading mt-2">Informasi Ketua Kelompok</h3>
                                                    <p class="mt-3">Nama: <?php echo e($data->nama); ?></p>
                                                    <p class="mt--3">Pekerjaan: <?php echo e($data->pekerjaan); ?></p>
                                                    <p class="mt--3">Pendidikan Terakhir: <?php echo e($data->pendidikan); ?></p>
                                                    <p class="mt--3">Jenis Kelamin: <?php echo e($data->jenis_kelamin); ?></p>
                                                    <p class="mt--3">No. Hp: <?php echo e($data->no_hp); ?></p>

                                                    <h3 class="heading mt-5">Informasi Lembaga</h3>
                                                    <p class="mt-3">Nama Lembaga: <?php echo e($data->nama_lembaga); ?></p>
                                                    <p class="mt--3">Email Lembaga: <?php echo e($data->email_lembaga); ?></p>
                                                    <p class="mt--3">Alamat Lembaga: <?php echo e($data->alamat_lembaga); ?></p>
                                                    <p class="mt--3">No. Hp Lembaga: <?php echo e($data->no_hp_lembaga); ?></p>
                                                    <p class="mt--3">Jumlah Peserta: <?php echo e($data->jumlah_peserta); ?></p>
                                                </div>
                                                
                                            </div>
                                            
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-link text-white ml-auto" data-dismiss="modal">Close</button> 
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              
                            </tbody>
                        </table>                            
                    </div>

                    <div class="card-footer py-4">
                        <nav class="d-flex justify-content-end" aria-label="...">
                            <?php echo e($guest->links()); ?>

                        </nav>
                    </div>
                </div>
            </div>
        </div>
            
        <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <script>
        
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['title' => __('User Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\repolib\resources\views/guestbook/index.blade.php ENDPATH**/ ?>