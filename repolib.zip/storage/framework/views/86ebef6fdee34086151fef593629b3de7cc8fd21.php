<style>
    @media  screen and (min-width: 768px) {
        #navbar-main-user {
            background-color: white;
        }
    }
</style>


<!-- Top navbar -->
<?php if(auth()->user()->level == 4): ?>
<nav class="navbar navbar-default navbar-top navbar-expand-md navbar-dark" id="navbar-main-user">
<?php else: ?>
<nav class="navbar navbar-top navbar-expand-md navbar-dark" id="navbar-main">
<?php endif; ?>
    <div class="container-fluid">
        <!-- Brand -->
        <?php if(auth()->user()->level != 4): ?>
            <a class="h4 mb-0 text-white text-uppercase d-none d-lg-inline-block" href="<?php echo e(route('home')); ?>"><?php echo e(__('Dashboard')); ?></a>
        <?php endif; ?>
        <!-- Form -->
        <form class="form-inline mr-4 d-none d-md-flex ml-lg-auto">
           
        </form>
        <!-- User -->
        <ul class="navbar-nav align-items-center d-none d-md-flex">
            <li class="nav-item dropdown">
                <a class="nav-link pr-0" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <div class="media align-items-center">
                        <span class="avatar avatar-sm rounded-circle">
                            <?php
                                $profile = App\Profile::where('user_id', auth()->user()->id)->get();
                            ?>
                            <?php $__currentLoopData = $profile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($data->foto ==  null): ?>
                                    <img alt="Image placeholder" src="<?php echo e(asset('argon')); ?>/img/theme/team-4-800x800.jpg">
                                <?php else: ?>
                                    <img alt="Image placeholder" src="<?php echo e(asset('storage')); ?>/profile/<?php echo e($data->foto); ?>">
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </span>
                        <div class="media-body ml-2 d-none d-lg-block">
                            <?php if(auth()->user()->level == 4): ?>
                            <span class="mb-0 text-sm  font-weight-bold" style="color:blue"><?php echo e(auth()->user()->name); ?></span>
                            <?php else: ?>
                            <span class="mb-0 text-sm  font-weight-bold"><?php echo e(auth()->user()->name); ?></span>    
                            <?php endif; ?>
                        </div>
                    </div>
                </a>
                <div class="dropdown-menu dropdown-menu-arrow dropdown-menu-right">
                    <a href="<?php echo e(route('profile.edit')); ?>" class="dropdown-item">
                        <i class="ni ni-single-02"></i>
                        <span><?php echo e(__('My Profile')); ?></span>
                    </a>
                    <div class="dropdown-divider"></div>
                    <a href="<?php echo e(route('logout')); ?>" class="dropdown-item" onclick="event.preventDefault();
                    document.getElementById('logout-form').submit();">
                        <i class="fas fa-sign-out-alt"></i>
                        <span><?php echo e(__('Logout')); ?></span>
                    </a>
                </div>
            </li>
        </ul>
    </div>
</nav><?php /**PATH D:\repolib\resources\views/layouts/navbars/navs/auth.blade.php ENDPATH**/ ?>