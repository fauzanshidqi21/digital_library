<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.headers.cards', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="<?php echo e(asset('jquery')); ?>/dist/jquery.min.js"></script>
    <script>
        $(document).ready(function(){
            $("#myInput").on("keyup", function() {
                var value = $(this).val().toLowerCase();
                $("#myTable tr").filter(function() {
                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                });
            });
        });
    </script>

    <div class="container-fluid mt--7">
        <div class="row">
            <div class="col">
                <div class="card shadow">
                    <div class="card-header border-0">
                        <div class="row align-items-center">
                            <div class="col-8">
                                <h3 class="mb-0">Peminjaman</h3>
                            </div>
                            <div class="col-4 text-right">
                                <a href="/peminjaman/buku" class="btn btn-sm btn-primary">
                                    <span><?php echo e(__('Pinjam Buku')); ?></span>
                                </a>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="form-group">
                            <div class="input-group input-group-alternative mb-4">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="ni ni-zoom-split-in"></i></span>
                            </div>
                            <input id="myInput" class="form-control form-control-alternative" placeholder="Search" type="text">
                            </div>
                        </div>
                    </div>

                    <div class="col-12">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <?php echo e(session('status')); ?>

                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="table-responsive">
                        <table class="table align-items-center table-flush">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col"><?php echo e(__('No.')); ?></th>
                                    <th scope="col"><?php echo e(__('Kode Peminjaman')); ?></th>
                                    <th scope="col"><?php echo e(__('Judul Buku')); ?></th>
                                    <?php if(auth()->user()->level != 4): ?>
                                        <th scope="col"><?php echo e(__('Kode Anggota')); ?></th>
                                    <?php endif; ?>
                                    <th scope="col"><?php echo e(__('Tanggal Pinjam')); ?></th>
                                    <th scope="col"><?php echo e(__('Batas Peminjaman')); ?></th>
                                    <th scope="col"><?php echo e(__('Tanggal Kembali')); ?></th>
                                    <th scope="col"><?php echo e(__('Status Buku')); ?></th>
                                    <th scope="col"><?php echo e(__('Total Denda')); ?></th>
                                    <th scope="col"><?php echo e(__('Status Denda')); ?></th>
                                    <th scope="col"><?php echo e(__('Action')); ?></th>    
                                </tr>
                            </thead>
                            <tbody id="myTable">
                                <?php
                                    $i = 1;
                                ?>
                               <?php $__currentLoopData = $peminjaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <?php if(auth()->user()->kode_anggota == $data->kode_anggota): ?>
                                <tr>
                                    <td><?php echo e($i++); ?></td>
                                    <td class="kode"><?php echo e($data->kode_peminjaman); ?></td>
                                    <td><?php echo e($data->judul); ?> <?php echo e($data->anak_judul); ?></td>
                                    <td><?php echo e($data->tanggal_pinjam); ?></td>
                                    <td><?php echo e($data->tanggal_batas_pinjam); ?></td>
                                    <td><?php echo e($data->tanggal_kembali); ?></td>
                                    <td><?php echo e($data->status); ?></td>
                                    <td><?php echo e($data->denda); ?></td>
                                    <td><?php echo e($data->status_denda); ?></td>
                                    <td>
                                        <?php if($data->status === 'Pending'): ?>
                                            <a href="/peminjaman/cancel/<?php echo e($data->kode_peminjaman); ?>">
                                                <button  type="button" class="btn btn-sm btn-danger">Cancel</button>
                                            </a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                               <?php elseif(auth()->user()->level != 4): ?>
                                <tr>
                                    <td><?php echo e($i++); ?></td>
                                    <td><?php echo e($data->kode_peminjaman); ?></td>
                                    <td><?php echo e($data->judul); ?> <?php echo e($data->anak_judul); ?></td>
                                    <td><?php echo e($data->kode_anggota); ?></td>
                                    <td><?php echo e($data->tanggal_pinjam); ?></td>
                                    <td><?php echo e($data->tanggal_batas_pinjam); ?></td>
                                    <td><?php echo e($data->tanggal_kembali ?? '-'); ?></td>
                                    <td><?php echo e($data->status); ?></td>
                                    <td>
                                        <?php if($data->denda != null): ?>
                                            <?php echo e($data->mata_uang_id); ?>  <?php echo e(number_format($data->denda,2)); ?>

                                        <?php else: ?>
                                            <?php echo e('-'); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($data->status_denda ?? '-'); ?></td>

                                    <td class="text-right">
                                        <div class="row">
                                            <div class="">
                                                <div class="d-flex justify-content-between align-items-baseline">
                                                    <?php if(auth()->user()->level != 3): ?>
                                                        <div class="row">
                                                            <div class="col-12">
                                                                <div class="d-flex align-items-center">
                                                                    <?php if($data->id == 1): ?>
                                                                        <a href="/peminjaman/<?php echo e($data->kode_peminjaman); ?>/pinjam" class="btn btn-sm btn-success mr-3"><?php echo e(__('Approve')); ?></a>
                                                                        <a href="/peminjaman/<?php echo e($data->kode_peminjaman); ?>/ditolak" class="btn btn-sm btn-danger mr-3"><?php echo e(__('Reject')); ?></a>
                                                                    <?php elseif($data->id == 2): ?>
                                                                        <form action="/peminjaman/delete/<?php echo e($data->kode_peminjaman); ?>" method="post">
                                                                            <?php echo csrf_field(); ?>
                                                                            <?php echo method_field('delete'); ?>
                                                                            
                                                                            <button type="button" class="btn btn-sm btn-danger mr-3" onclick="confirm('<?php echo e(__("Are you sure you want to delete this transaction?")); ?>') ? this.parentElement.submit() : '' ">
                                                                                <?php echo e(__('Delete')); ?>

                                                                            </button>
                                                                        </form>
                                                                    <?php elseif($data->id < 4): ?>
                                                                        <a href="/peminjaman/<?php echo e($data->kode_peminjaman); ?>/kembali" class="btn btn-sm btn-primary mr-3"><?php echo e(__('Buku Kembali')); ?></a>
                                                                        <a href="/peminjaman/<?php echo e($data->kode_peminjaman); ?>/hilang" class="btn btn-sm btn-primary"><?php echo e(__('Buku Hilang')); ?></a>
                                                                    <?php elseif(($data->id > 4 && $data->status_denda != 'lunas') && $data->id != 7): ?>
                                                                        <form action="/peminjaman/pembayaran/<?php echo e($data->peminjaman_id); ?>" method="post">
                                                                            <?php echo csrf_field(); ?>
                                                                            <?php echo method_field('put'); ?>
                                                                            
                                                                            <button class="btn btn-sm btn-primary mr-3" type="button" class="dropdown-item" onclick="confirm('Apakah Anda yakin peminjaman ini sudah lunas?') ? this.parentElement.submit() : '' ">
                                                                                <?php echo e(__('Pembayaran')); ?>

                                                                            </button>
                                                                        </form>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>      
                                            </div>
                                        </div>                                           
                                    </td>
                                </tr>
                               <?php endif; ?>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              
                            </tbody>
                        </table>
                    </div>
                    <div class="card-footer py-4">
                        <nav class="d-flex justify-content-end" aria-label="...">
                            <?php echo e($peminjaman->links()); ?>

                        </nav>
                    </div>
                </div>
            </div>
        </div>
            
        <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['title' => __('User Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\repolib\resources\views/transactions/index.blade.php ENDPATH**/ ?>