<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.headers.cards', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <div class="container-fluid mt--7">
        <div class="row">
            <div class="col">
                <div class="card shadow">
                    <div class="card-header border-0">
                        <div class="row align-items-center">
                            <div class="col-8">
                                <h3 class="mb-0">Carousel Event</h3>
                            </div>
                        </div>
                    </div>

                    <div class="col-12">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <?php echo e(session('status')); ?>

                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="card-body">
                        <div class="row">
                            
                            <div class="col-lg-6">
                                <hr class="my-4"/>
                                <h6 class="heading-small text-muted mt-4"><?php echo e(__('First Carousel')); ?></h6>
                                
                                <?php if($carouselFirst != null): ?> 
                                    <img style="max-width:100%; max-height:100%" src="<?php echo e(asset('storage')); ?>/carousel/<?php echo e($carouselFirst); ?>" alt="">
                                <?php else: ?>
                                    <img style="max-width:100%; max-height:100%" src="<?php echo e(asset('argon')); ?>/img/carousel/default1.jpg" alt="">
                                <?php endif; ?>

                                <form enctype="multipart/form-data" action="/carousel-event/1" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('put'); ?>
    
                                    
                                    <div class="form-group<?php echo e($errors->has('cover') ? ' has-danger' : ''); ?> mt-3">
                                        <label for="cover" class="form-control-label"><?php echo e(__('Change First Carousel')); ?></label>
                
                                        <input type="file" class="form-control-file<?php echo e($errors->has('cover') ? ' is-invalid' : ''); ?>" id="cover" name="cover" required>
                                        
                                        <div>
                                            <?php if($errors->has('cover')): ?>
                                                <span style="color:#f5365c">
                                                    <small>
                                                        <strong><?php echo e($errors->first('cover')); ?></strong>
                                                    </small>
                                                </span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="text-center">
                                            <button type="submit" class="btn btn-success mt-4"><?php echo e(__('Change')); ?></button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            
                            
                            <div class="col-lg-6">
                                <hr class="my-4"/>
                                <h6 class="heading-small text-muted mt-4"><?php echo e(__('Second Carousel')); ?></h6>
                                
                                <?php if($carouselSecond != null): ?> 
                                    <img style="max-width:100%; max-height:100%" src="<?php echo e(asset('storage')); ?>/carousel/<?php echo e($carouselSecond); ?>" alt="">
                                <?php else: ?>
                                    <img style="max-width:100%; max-height:100%" src="<?php echo e(asset('argon')); ?>/img/carousel/default2.jpg" alt="">
                                <?php endif; ?>

                                <form enctype="multipart/form-data" action="/carousel-event/2" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('put'); ?>
    
                                    
                                    <div class="form-group<?php echo e($errors->has('cover') ? ' has-danger' : ''); ?> mt-3">
                                        <label for="cover" class="form-control-label"><?php echo e(__('Change Second Carousel')); ?></label>
                
                                        <input type="file" class="form-control-file<?php echo e($errors->has('cover') ? ' is-invalid' : ''); ?>" id="cover" name="cover" required>
                                        
                                        <div>
                                            <?php if($errors->has('cover')): ?>
                                                <span style="color:#f5365c">
                                                    <small>
                                                        <strong><?php echo e($errors->first('cover')); ?></strong>
                                                    </small>
                                                </span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="text-center">
                                            <button type="submit" class="btn btn-success mt-4"><?php echo e(__('Change')); ?></button>
                                        </div>
                                    </div>
                                </form>
                            </div>

                            
                            <div class="col-lg-6">
                                <hr class="my-4"/>
                                <h6 class="heading-small text-muted mt-4"><?php echo e(__('Third Carousel')); ?></h6>
                                
                                <?php if($carouselThird != null): ?> 
                                    <img style="max-width:100%; max-height:100%" src="<?php echo e(asset('storage')); ?>/carousel/<?php echo e($carouselThird); ?>" alt="">
                                <?php else: ?>
                                    <img style="max-width:100%; max-height:100%" src="<?php echo e(asset('argon')); ?>/img/carousel/default3.jpg" alt="">
                                <?php endif; ?>

                                <form enctype="multipart/form-data" action="/carousel-event/3" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('put'); ?>
    
                                    
                                    <div class="form-group<?php echo e($errors->has('cover') ? ' has-danger' : ''); ?> mt-3">
                                        <label for="cover" class="form-control-label"><?php echo e(__('Change Third Carousel')); ?></label>
                
                                        <input type="file" class="form-control-file<?php echo e($errors->has('cover') ? ' is-invalid' : ''); ?>" id="cover" name="cover" required>
                                        
                                        <div>
                                            <?php if($errors->has('cover')): ?>
                                                <span style="color:#f5365c">
                                                    <small>
                                                        <strong><?php echo e($errors->first('cover')); ?></strong>
                                                    </small>
                                                </span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="text-center">
                                            <button type="submit" class="btn btn-success mt-4"><?php echo e(__('Change')); ?></button>
                                        </div>
                                    </div>
                                </form>
                            </div>

                            
                            <div class="col-lg-6">
                                <hr class="my-4"/>
                                <h6 class="heading-small text-muted mt-4"><?php echo e(__('Fourth Carousel')); ?></h6>
                                
                                <?php if($carouselFourth != null): ?> 
                                    <img style="max-width:100%; max-height:100%" src="<?php echo e(asset('storage')); ?>/carousel/<?php echo e($carouselFourth); ?>" alt="">
                                <?php else: ?>
                                    <img style="max-width:100%; max-height:100%" src="<?php echo e(asset('argon')); ?>/img/carousel/default4.jpg" alt="">
                                <?php endif; ?>
                            
                                <form enctype="multipart/form-data" action="/carousel-event/4" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('put'); ?>
    
                                    
                                    <div class="form-group<?php echo e($errors->has('cover') ? ' has-danger' : ''); ?> mt-3">
                                        <label for="cover" class="form-control-label"><?php echo e(__('Change Fourth Carousel')); ?></label>
                
                                        <input type="file" class="form-control-file<?php echo e($errors->has('cover') ? ' is-invalid' : ''); ?>" id="cover" name="cover" required>
                                        
                                        <div>
                                            <?php if($errors->has('cover')): ?>
                                                <span style="color:#f5365c">
                                                    <small>
                                                        <strong><?php echo e($errors->first('cover')); ?></strong>
                                                    </small>
                                                </span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="text-center">
                                            <button type="submit" class="btn btn-success mt-4"><?php echo e(__('Change')); ?></button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\repolib\resources\views/carousel.blade.php ENDPATH**/ ?>