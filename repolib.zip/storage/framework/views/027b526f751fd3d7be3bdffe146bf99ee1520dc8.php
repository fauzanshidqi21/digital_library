<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('users.partials.header', ['title' => __('Add Book Data')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   
    <script src="<?php echo e(asset('jquery')); ?>/dist/jquery.min.js"></script>
    <script>
        $(document).ready(function(){
            var val = document.getElementById('input-deskripsi').value;
            var count = val.length;
            var max = 200 - count;
            var label_text = 'Tersisa: ' + max + ' karakter';
            var label = document.getElementById('max');
            label.textContent = label_text;

            $("#input-deskripsi").on("keyup", function() {
                val = $(this).val();
                count = val.length;
                max = 200 - count;
                label_text = 'Tersisa: ' + max + ' karakter';
                label = document.getElementById('max');
                label.textContent = label_text;
            });
        });
    </script>

    <div class="container-fluid mt--7">
        <div class="row">
            <div class="col-xl-12 order-xl-1">
                <div class="card bg-secondary shadow">
                    <div class="card-header bg-white border-0">
                        <div class="row align-items-center">
                            <div class="col-8">
                                
                            </div>
                            <div class="col-4 text-right">
                                <a href="/bibliografi/book" class="btn btn-sm btn-primary"><?php echo e(__('Back to list')); ?></a>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <form enctype="multipart/form-data" method="post" action="/bibliografi/book" autocomplete="off">
                            <?php echo csrf_field(); ?>
                            
                            <h6 class="heading-small text-muted mb-4"><?php echo e(__('Bibliografi Information')); ?></h6>                                    
                            <div class="pl-lg-4">
                                
                                <div class="form-group<?php echo e($errors->has('judul') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-judul"><?php echo e(__('Judul')); ?></label>
                                    <input type="text" name="judul" id="input-judul" class="form-control form-control-alternative<?php echo e($errors->has('judul') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Judul')); ?>" value="<?php echo e(old('judul')); ?>" required autofocus>

                                    <?php if($errors->has('judul')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('judul')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>

                                
                                <div class="form-group<?php echo e($errors->has('anak_judul') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-anak_judul"><?php echo e(__('Anak Judul')); ?></label>
                                    <input type="text" name="anak_judul" id="input-anak_judul" class="form-control form-control-alternative<?php echo e($errors->has('anak_judul') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Anak Judul')); ?>" value="<?php echo e(old('anak_judul')); ?>" required autofocus>

                                    <?php if($errors->has('anak_judul')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('anak_judul')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>

                                
                                <div class="form-group<?php echo e($errors->has('isbn') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-isbn"><?php echo e(__('ISBN')); ?></label>
                                    <input type="text" name="isbn" id="input-isbn" class="form-control form-control-alternative<?php echo e($errors->has('isbn') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('ISBN')); ?>" value="<?php echo e(old('isbn')); ?>">

                                    <?php if($errors->has('isbn')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('isbn')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>

                                
                                <div class="form-group<?php echo e($errors->has('no_panggil') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-no_panggil"><?php echo e(__('No. Panggil')); ?></label>
                                    <input type="text" name="no_panggil" id="input-no_panggil" class="form-control form-control-alternative<?php echo e($errors->has('no_panggil') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('No. Panggil')); ?>" value="<?php echo e(old('no_panggil')); ?>">

                                    <?php if($errors->has('no_panggil')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('no_panggil')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>

                                
                                <div class="form-group<?php echo e($errors->has('edisi') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-edisi"><?php echo e(__('Edisi')); ?></label>
                                    <input type="text" name="edisi" id="input-edisi" class="form-control form-control-alternative<?php echo e($errors->has('edisi') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Edisi / Cetakan')); ?>" value="<?php echo e(old('edisi')); ?>">

                                    <?php if($errors->has('edisi')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('edisi')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>

                                
                                <div class="form-group">
                                    <label class="form-control-label"><?php echo e(__('Bahasa')); ?></label>
                                    <div class="d-flex align-items-end flex-column pt-2">
                                        <div class="input-group pb-3">
                                            <select class="custom-select" name="bahasa" id="bahasa">
                                                <option></option>
                                                <?php $__currentLoopData = $bahasa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if(old('bahasa') == $bhs->id): ?>
                                                        <option value="<?php echo e($bhs->id); ?>" selected><?php echo e($bhs->bahasa); ?></option>
                                                    <?php else: ?>
                                                        <option value="<?php echo e($bhs->id); ?>"><?php echo e($bhs->bahasa); ?></option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>

                                        <div>
                                            <button class="btn btn-outline-primary" type="button" data-toggle="modal" data-target="#bahasa-form">Tambah</button>
                                        </div>
                                    </div>
                                </div>

                                
                                <div class="form-group">
                                    <label class="form-control-label"><?php echo e(__('Kategori')); ?></label>
                                    <div class="d-flex align-items-end flex-column pt-2">
                                        <div class="input-group pb-3">
                                            <select class="custom-select" name="kategori" id="kategori">
                                                <option></option>
                                                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ktgr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if(old('kategori') == $ktgr->id): ?>
                                                        <option value="<?php echo e($ktgr->id); ?>" selected><?php echo e($ktgr->kategori); ?></option>
                                                    <?php else: ?>
                                                        <option value="<?php echo e($ktgr->id); ?>"><?php echo e($ktgr->kategori); ?></option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>

                                        <div>
                                            <button class="btn btn-outline-primary" type="button" data-toggle="modal" data-target="#kategori-form">Tambah</button>
                                        </div>
                                    </div>
                                </div>

                                
                                <div class="form-group">
                                    <label class="form-control-label"><?php echo e(__('Akses')); ?></label>
                                    <div class="d-flex align-items-end flex-column pt-2">
                                        <div class="input-group pb-3">
                                            <select class="custom-select" name="akses" id="akses">
                                                <option></option>
                                                <?php $__currentLoopData = $akses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if(old('akses') == $acc->id): ?>
                                                        <option value="<?php echo e($acc->id); ?>" selected><?php echo e($acc->akses); ?></option>
                                                    <?php else: ?>
                                                        <option value="<?php echo e($acc->id); ?>"><?php echo e($acc->akses); ?></option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>

                                        <div>
                                            <button class="btn btn-outline-primary" type="button" data-toggle="modal" data-target="#akses-form">Tambah</button>
                                        </div>
                                    </div>
                                </div>

                                
                                <div class="form-group">
                                    <label class="form-control-label"><?php echo e(__('Lokasi')); ?></label>
                                    <div class="d-flex align-items-end flex-column pt-2">
                                        <div class="input-group pb-3">
                                            <select class="custom-select" name="lokasi" id="lokasi">
                                                <option></option>
                                                <?php $__currentLoopData = $lokasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if(old('lokasi') == $loc->id): ?>
                                                        <option value="<?php echo e($loc->id); ?>" selected><?php echo e($loc->lokasi); ?></option>
                                                    <?php else: ?>
                                                        <option value="<?php echo e($loc->id); ?>"><?php echo e($loc->lokasi); ?></option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>

                                        <div>
                                            <button class="btn btn-outline-primary" type="button" data-toggle="modal" data-target="#lokasi-form">Tambah</button>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <h6 class="heading-small text-muted pt-5 mb-4"><?php echo e(__('Book Information')); ?></h6>
                            <div class="pl-lg-4">
                                
                                <div class="form-group<?php echo e($errors->has('penerbit') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-penerbit"><?php echo e(__('Penerbit')); ?></label>
                                    <input type="text" name="penerbit" id="input-penerbit" class="form-control form-control-alternative<?php echo e($errors->has('penerbit') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Penerbit')); ?>" value="<?php echo e(old('penerbit')); ?>">

                                    <?php if($errors->has('penerbit')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('penerbit')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
    
                                
                                <div class="form-group<?php echo e($errors->has('tempat_terbit') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-tempat_terbit"><?php echo e(__('Tempat Terbit')); ?></label>
                                    <input type="text" name="tempat_terbit" id="input-tempat_terbit" class="form-control form-control-alternative<?php echo e($errors->has('tempat_terbit') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Tempat Terbit')); ?>" value="<?php echo e(old('tempat_terbit')); ?>">

                                    <?php if($errors->has('tempat_terbit')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('tempat_terbit')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
    
                                
                                <div class="form-group<?php echo e($errors->has('tahun_terbit') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-tahun_terbit"><?php echo e(__('Tahun Terbit')); ?></label>
                                    <input type="text" name="tahun_terbit" id="input-tahun_terbit" class="form-control form-control-alternative<?php echo e($errors->has('tahun_terbit') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Tahun Terbit')); ?>" value="<?php echo e(old('tahun_terbit')); ?>">

                                    <?php if($errors->has('tahun_terbit')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('tahun_terbit')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>

                                
                                <div class="form-group<?php echo e($errors->has('jumlah_halaman') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-jumlah_halaman"><?php echo e(__('Jumlah Halaman')); ?></label>
                                    <input type="text" name="jumlah_halaman" id="input-jumlah_halaman" class="form-control form-control-alternative<?php echo e($errors->has('jumlah_halaman') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Jumlah Halaman')); ?>" value="<?php echo e(old('jumlah_halaman')); ?>">

                                    <?php if($errors->has('jumlah_halaman')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('jumlah_halaman')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                    
                                
                                <div class="form-group<?php echo e($errors->has('jumlah_buku') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-jumlah_buku"><?php echo e(__('Jumlah Buku')); ?></label>
                                    <input type="text" name="jumlah_buku" id="input-jumlah_buku" class="form-control form-control-alternative<?php echo e($errors->has('jumlah_buku') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Jumlah Buku')); ?>" value="<?php echo e(old('jumlah_buku')); ?>">

                                    <?php if($errors->has('jumlah_buku')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('jumlah_buku')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>

                                
                                <div class="form-group<?php echo e($errors->has('tinggi_buku') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-tinggi_buku"><?php echo e(__('Tinggi Buku')); ?></label>
                                    <input type="text" name="tinggi_buku" id="input-tinggi_buku" class="form-control form-control-alternative<?php echo e($errors->has('tinggi_buku') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Tinggi Buku')); ?>" value="<?php echo e(old('tinggi_buku')); ?>">

                                    <?php if($errors->has('tinggi_buku')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('tinggi_buku')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>

                                
                                <div class="form-group">
                                    <label class="form-control-label"><?php echo e(__('Klasifikasi Buku')); ?></label>
                                    <div class="d-flex align-items-end flex-column pt-2">
                                        <div class="input-group pb-3">
                                            <select class="form-control" name="klasifikasi_buku" id="klasifikasi_buku">
                                                <option></option>
                                                <?php $__currentLoopData = $klasifikasi_buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if(old('klasifikasi_buku') == $kb->id): ?>
                                                        <option value="<?php echo e($kb->id); ?>" selected><?php echo e($kb->klasifikasi_buku); ?></option>
                                                    <?php else: ?>
                                                        <option value="<?php echo e($kb->id); ?>"><?php echo e($kb->klasifikasi_buku); ?></option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>

                                        <div>
                                            <button class="btn btn-outline-primary" type="button" data-toggle="modal" data-target="#klasifikasi_buku-form">Tambah</button>
                                        </div>
                                    </div>
                                </div>

                                
                                <div class="form-group">
                                    <label class="form-control-label"><?php echo e(__('Subjek Buku')); ?></label>
                                    <div class="d-flex align-items-end flex-column pt-2">
                                        <div class="input-group pb-3">
                                            <select class="form-control" name="subjek_buku" id="subjek_buku">
                                                <option></option>
                                                <?php $__currentLoopData = $subjek_buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if(old('subjek_buku') == $sb->id): ?>
                                                        <option value="<?php echo e($sb->id); ?>" selected><?php echo e($sb->subjek); ?></option>
                                                    <?php else: ?>
                                                        <option value="<?php echo e($sb->id); ?>"><?php echo e($sb->subjek); ?></option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>

                                        <div>
                                            <button class="btn btn-outline-primary" type="button" data-toggle="modal" data-target="#subjek_buku-form">Tambah</button>
                                        </div>
                                    </div>
                                </div>

                                
                                <div class="form-group">
                                    <label class="form-control-label"><?php echo e(__('Bentuk Karya Tulis')); ?></label>
                                    <div class="d-flex align-items-end flex-column pt-2">
                                        <div class="input-group pb-3">
                                            <select class="form-control" name="karya_tulis" id="karya_tulis">
                                                <option></option>
                                                <?php $__currentLoopData = $karya_tulis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if(old('karya_tulis') == $kt->id): ?>
                                                        <option value="<?php echo e($kt->id); ?>" selected><?php echo e($kt->bentuk_karya_tulis); ?></option>
                                                    <?php else: ?>
                                                        <option value="<?php echo e($kt->id); ?>"><?php echo e($kt->bentuk_karya_tulis); ?></option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>

                                        <div>
                                            <button class="btn btn-outline-primary" type="button" data-toggle="modal" data-target="#karya_tulis-form">Tambah</button>
                                        </div>
                                    </div>
                                </div>

                                
                                <div class="form-group">
                                    <label class="form-control-label"><?php echo e(__('Jenis Buku')); ?></label>
                                    <div class="d-flex align-items-end flex-column pt-2">
                                        <div class="input-group pb-3">
                                            <select class="form-control" name="jenis_buku" id="jenis_buku">
                                                <option></option>
                                                <?php $__currentLoopData = $jenis_buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if(old('jenis_buku') == $jb->id): ?>
                                                        <option value="<?php echo e($jb->id); ?>" selected><?php echo e($jb->jenis_buku); ?></option>
                                                    <?php else: ?>
                                                        <option value="<?php echo e($jb->id); ?>"><?php echo e($jb->jenis_buku); ?></option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>

                                        <div>
                                            <button class="btn btn-outline-primary" type="button" data-toggle="modal" data-target="#jenis_buku-form">Tambah</button>
                                        </div>
                                    </div>
                                </div>

                                
                                <div class="form-group">
                                    <label class="form-control-label"><?php echo e(__('OPAC')); ?></label>
                                    <div class="custom-control custom-radio mb-4">
                                        <input name="opac" class="custom-control-input" id="show" type="radio" value="show" checked>
                                        <label class="custom-control-label" for="show">Show</label>
                                    </div>
                                    <div class="custom-control custom-radio mb-3">
                                        <input name="opac" class="custom-control-input" id="hide" type="radio" value="hide">
                                        <label class="custom-control-label" for="hide">Hide</label>
                                    </div>
                                </div>

                                
                                <div class="form-group<?php echo e($errors->has('cover') ? ' has-danger' : ''); ?>">
                                    <label for="cover" class="form-control-label"><?php echo e(__('Book Cover')); ?></label>
            
                                    <input type="file" class="form-control-file<?php echo e($errors->has('cover') ? ' is-invalid' : ''); ?>" id="cover" name="cover">
                                    
                                    <div>
                                        <?php if($errors->has('cover')): ?>
                                            <span style="color:#f5365c">
                                                <small>
                                                    <strong><?php echo e($errors->first('cover')); ?></strong>
                                                </small>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                
                                <div class="form-group<?php echo e($errors->has('file') ? ' has-danger' : ''); ?>">
                                    <label for="input-file" class="form-control-label"><?php echo e(__('Book File')); ?></label>
                                    <input type="file" class="form-control-file<?php echo e($errors->has('file') ? ' is-invalid' : ''); ?>" id="input-file" name="file">
                                </div>

                                <div>
                                    <?php if($errors->has('file')): ?>
                                        <span style="color:#f5365c">
                                            <small>
                                                <strong><?php echo e($errors->first('file')); ?></strong>
                                            </small>
                                        </span>
                                    <?php endif; ?>
                                </div>

                                
                                <div class="form-group<?php echo e($errors->has('deskripsi') ? ' has-danger' : ''); ?>">
                                    <div class="row align-items-center">
                                        <div class="col-12">
                                            <label class="form-control-label pt-3" for="input-deskripsi"><?php echo e(__('Deskripsi Buku')); ?></label>
                                        </div>
                                        
                                        <div class="col-12 pb-3">
                                            <textarea maxlength="200" style="height:180px" name="deskripsi" id="input-deskripsi" class="form-control form-control-alternative<?php echo e($errors->has('deskripsi') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Deskripsi Buku')); ?>"><?php echo e(old('deskripsi')); ?></textarea>
                                        </div>
                                        
                                        <div class="col-12 text-right">
                                            <label class="text-right" id="max" for="input-deskripsi"><?php echo e(__('Tersisa: 200 Karakter')); ?></label>
                                        </div>
                                    </div>

                                    <?php if($errors->has('deskripsi')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('deskripsi')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="d-flex justify-content-between align-items-baseline">
                                <h6 class="heading-small text-muted pt-5 mb-4"><?php echo e(__('Author Information')); ?></h6>
                                <button class="btn btn-sm btn-outline-primary" type="button" data-toggle="modal" data-target="#author-form">Tambah</button>
                            </div>
                            <div class="pl-lg-4">
                                
                                <div class="form-group">
                                    <label class="form-control-label"><?php echo e(__('Pengarang Utama')); ?></label>
                                    <div class="d-flex align-items-end flex-column pt-2">
                                        <div class="input-group pb-3">
                                            <select class="form-control" name="authorPrimary" id="authorPrimary">
                                                <option></option>
                                                <?php $__currentLoopData = $authorPrimary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ap): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if(old('authorPrimary') == $ap->id): ?>
                                                        <option value="<?php echo e($ap->id); ?>" selected><?php echo e($ap->name); ?></option>
                                                    <?php else: ?>
                                                        <option value="<?php echo e($ap->id); ?>"><?php echo e($ap->name); ?></option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                
                                <div class="form-group">
                                    <label class="form-control-label"><?php echo e(__('Pengarang Tambahan')); ?></label>
                                    <div class="d-flex align-items-end flex-column pt-2">
                                        <div class="input-group pb-3">
                                            <select class="form-control" name="authorAdditional[]" id="authorAdditional" multiple="multiple">
                                                <option></option>
                                                <?php $__currentLoopData = $authorAdditional; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ap): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($ap->id); ?>"><?php echo e($ap->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <h6 class="heading-small text-muted pt-5 mb-4"><?php echo e(__('Book Source')); ?></h6>
                            <div class="pl-lg-4">
                                
                                <div class="form-group">
                                    <label class="form-control-label"><?php echo e(__('Jenis Sumber')); ?></label>
                                    <div class="d-flex align-items-end flex-column pt-2">
                                        <div class="input-group pb-3">
                                            <select class="form-control" name="jenis" id="jenis">
                                                <option></option>
                                                <?php $__currentLoopData = $sumber; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $js): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if(old('jenis') == $js->id): ?>
                                                        <option value="<?php echo e($js->id); ?>" selected><?php echo e($js->jenis_sumber); ?></option>
                                                    <?php else: ?>
                                                        <option value="<?php echo e($js->id); ?>"><?php echo e($js->jenis_sumber); ?></option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>

                                        <div>
                                            <button class="btn btn-outline-primary" type="button" data-toggle="modal" data-target="#sumber-form">Tambah</button>
                                        </div>
                                    </div>
                                </div>

                                
                                <div class="form-group<?php echo e($errors->has('nama_sumber') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-nama_sumber"><?php echo e(__('Nama Sumber')); ?></label>
                                    <input type="text" name="nama_sumber" id="input-nama_sumber" class="form-control form-control-alternative<?php echo e($errors->has('nama_sumber') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Nama Sumber')); ?>" value="<?php echo e(old('nama_sumber')); ?>">

                                    <?php if($errors->has('nama_sumber')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('nama_sumber')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <h6 class="heading-small text-muted pt-5 mb-4"><?php echo e(__('Book Price')); ?></h6>
                            <div class="pl-lg-4">
                                
                                <div class="form-group">
                                    <label class="form-control-label"><?php echo e(__('Mata Uang')); ?></label>
                                    <div class="d-flex align-items-end flex-column pt-2">
                                        <div class="input-group pb-3">
                                            <select class="form-control" name="mata_uang" id="mata_uang">
                                                <option></option>
                                                <?php $__currentLoopData = $currency; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if(old('mata_uang') == $mu->code): ?>
                                                        <option value="<?php echo e($mu->code); ?>" selected><?php echo e($mu->currency); ?>  (<?php echo e($mu->code); ?>)</option>
                                                    <?php else: ?>
                                                        <option value="<?php echo e($mu->code); ?>"><?php echo e($mu->currency); ?>  (<?php echo e($mu->code); ?>)</option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>

                                        <div>
                                            <button class="btn btn-outline-primary" type="button" data-toggle="modal" data-target="#currency-form">Tambah</button>
                                        </div>
                                    </div>
                                </div>

                                
                                <div class="form-group<?php echo e($errors->has('harga') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-harga"><?php echo e(__('Harga')); ?></label>
                                    <input type="text" name="harga" id="input-harga" class="form-control form-control-alternative<?php echo e($errors->has('harga') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Harga')); ?>" value="<?php echo e(old('harga')); ?>">

                                    <?php if($errors->has('harga')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('harga')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="text-center">
                                <button type="submit" class="btn btn-success mt-4"><?php echo e(__('Save')); ?></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
        <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    
    <?php echo $__env->make('bibliografi.books.addSection', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script type="text/javascript" src="<?php echo e(asset('argon')); ?>/vendor/jquery/dist/jquery.min.js"></script>
    <link href="<?php echo e(asset('select2')); ?>/dist/css/select2.min.css" rel="stylesheet"/>
    <script src="<?php echo e(asset('select2')); ?>/dist/js/select2.min.js"></script>
    <script src="<?php echo e(asset('js')); ?>/bibliografi.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['title' => __('User Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\repolib\resources\views/bibliografi/books/create.blade.php ENDPATH**/ ?>