<div class="row align-items-center justify-content-xl-between">
    <div class="col-xl-6">
        <div class="copyright text-center text-xl-left text-muted">
            &copy; <?php echo e(now()->year); ?> Repolib v1.0.1
        </div>
    </div>
    <div class="col-xl-6">
        <ul class="nav nav-footer justify-content-center justify-content-xl-end">
            <li class="nav-item">
                
            </li>
        </ul>
    </div>
</div><?php /**PATH D:\repolib\resources\views/layouts/footers/nav.blade.php ENDPATH**/ ?>