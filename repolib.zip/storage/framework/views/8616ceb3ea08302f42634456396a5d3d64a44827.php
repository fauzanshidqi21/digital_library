<nav class="navbar navbar-vertical fixed-left navbar-expand-md navbar-light bg-white" id="sidenav-main">
    <div class="container-fluid">
        <!-- Toggler -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#sidenav-collapse-main" aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <!-- Brand -->
        <a class="navbar-brand pt-0" href="<?php echo e(route('home')); ?>">
            <img src="<?php echo e(asset('argon')); ?>/img/brand/blue.png" class="navbar-brand-img" alt="...">
        </a>
        <!-- User -->
        <ul class="nav align-items-center d-md-none">
            <li class="nav-item dropdown">
                <a class="nav-link" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <div class="media align-items-center">
                        <span class="avatar avatar-sm rounded-circle">
                        <?php
                            $profile = App\Profile::where('user_id', auth()->user()->id)->get();
                        ?>
                        <?php $__currentLoopData = $profile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($data->foto ==  null): ?>
                                <img alt="Image placeholder" src="<?php echo e(asset('argon')); ?>/img/theme/team-4-800x800.jpg">
                            <?php else: ?>
                                <img alt="Image placeholder" src="<?php echo e(asset('storage')); ?>/profile/<?php echo e($data->foto); ?>">
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        </span>
                    </div>
                </a>
                <div class="dropdown-menu dropdown-menu-arrow dropdown-menu-right">
                    <a href="<?php echo e(route('profile.edit')); ?>" class="dropdown-item">
                        <i class="ni ni-single-02"></i>
                        <span><?php echo e(__('My Profile')); ?></span>
                    </a>
                    <div class="dropdown-divider"></div>
                    <a href="<?php echo e(route('logout')); ?>" class="dropdown-item" onclick="event.preventDefault();
                    document.getElementById('logout-form').submit();">
                        <i class="fas fa-sign-out-alt"></i>
                        <span><?php echo e(__('Logout')); ?></span>
                    </a>
                </div>
            </li>
        </ul>
        <!-- Collapse -->
        <div class="collapse navbar-collapse" id="sidenav-collapse-main">
            <!-- Collapse header -->
            <div class="navbar-collapse-header d-md-none">
                <div class="row">
                    <div class="col-6 collapse-brand">
                        <a href="<?php echo e(route('home')); ?>">
                            <img src="<?php echo e(asset('argon')); ?>/img/brand/blue.png">
                        </a>
                    </div>
                    <div class="col-6 collapse-close">
                        <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#sidenav-collapse-main" aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle sidenav">
                            <span></span>
                            <span></span>
                        </button>
                    </div>
                </div>
            </div>

            <!-- Navigation -->
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('home')); ?>">
                        <?php if(auth()->user()->level != 4): ?>
                            <i class="ni ni-tv-2" style="color: #00f;"></i>
                            <span class="nav-link-text" style="color: #00f;"><?php echo e(__('Dashboard')); ?></span>
                        <?php else: ?>
                            <i class="ni ni-tv-2" style="color: #00f;"></i>
                            <span class="nav-link-text" style="color: #00f;"><?php echo e(__('Home')); ?></span>
                        <?php endif; ?>
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="/peminjaman">
                        <i class="ni ni-books" style="color: #00f;"></i>
                        <span class="nav-link-text" style="color: #00f;"><?php echo e(__('Peminjaman')); ?></span>
                    </a>
                </li>

                <?php if(auth()->user()->level != 4): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="/opac">
                            <i class="ni ni-world" style="color: #00f;"></i>
                            <span class="nav-link-text" style="color: #00f;"><?php echo e(__('OPAC')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if(auth()->user()->level != 4): ?>
                    <li class="nav-item">
                        <a class="nav-link active" href="#navbar-master" data-toggle="collapse" role="button" aria-expanded="false" aria-controls="navbar-master">
                            <i class="ni ni-single-02" style="color: #00f;"></i>
                            <span class="nav-link-text" style="color: #00f;"><?php echo e(__('Master Data')); ?></span>
                        </a>
    
                        <div class="collapse hide" id="navbar-master">
                            <ul class="nav nav-sm flex-column">
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('profile.edit')); ?>">
                                        <?php echo e(__('User profile')); ?>

                                    </a>
                                </li>
                                <li class="nav-item">
                                        <a class="nav-link" href="/data/user">
                                            <?php echo e(__('Data User')); ?>

                                        </a>
                                    </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="/data/admin">
                                        <?php echo e(__('Data Anggota')); ?>

                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('profile.edit')); ?>">
                            <i class="ni ni-single-02" style="color: #00f;"></i>
                            <span class="nav-link-text" style="color: #00f;"><?php echo e(__('User Profile')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if(auth()->user()->level !== 4): ?>
                    <li class="nav-item">
                        <a class="nav-link active" href="#navbar-bibliografi" data-toggle="collapse" role="button" aria-expanded="false" aria-controls="navbar-bibliografi">
                            <i class="fas fa-bookmark" style="color: #00f;"></i>
                            <span class="nav-link-text" style="color: #00f;"><?php echo e(__('Monograf')); ?></span>
                        </a>
    
                        <div class="collapse hide" id="navbar-bibliografi">
                            <ul class="nav nav-sm flex-column">
                                <?php if(auth()->user()->level !== 3): ?>
                                <li class="nav-item">
                                        <a class="nav-link" href="/bibliografi/book">
                                            <?php echo e(__('Daftar Bibliografi')); ?>

                                        </a>
                                    </li>
    
                                    <li class="nav-item">
                                        <a class="nav-link" href="/bibliografi/book/author">
                                            <?php echo e(__('Daftar Pengarang')); ?>

                                        </a>
                                    </li>
                                <?php endif; ?>
                                
                                <?php if(auth()->user()->level !== 2): ?>
                                <li class="nav-item">
                                        <a class="nav-link" href="/bibliografi/cd">
                                            <?php echo e(__('Daftar CD/DVD')); ?>

                                        </a>
                                    </li>
    
                                    <li class="nav-item">
                                        <a class="nav-link" href="/bibliografi/cd/songwriter">
                                            <?php echo e(__('Daftar Pencipta Lagu')); ?>

                                        </a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="/guestbook-all-data">
                            <i class="fas fa-address-book" style="color: #00f;"></i>
                            <span class="nav-link-text" style="color: #00f;"><?php echo e(__('Buku Tamu')); ?></span>
                        </a>
                    </li>

                    <li class="nav-item">
                            <a class="nav-link" href="/carousel-event">
                                <i class="fas fa-images" style="color: #00f;"></i>
                                <span class="nav-link-text" style="color: #00f;"><?php echo e(__('Event')); ?></span>
                            </a>
                        </li>
                <?php endif; ?>
            </ul>

            
        </div>
    </div>
</nav><?php /**PATH D:\repolib\resources\views/layouts/navbars/sidebar.blade.php ENDPATH**/ ?>