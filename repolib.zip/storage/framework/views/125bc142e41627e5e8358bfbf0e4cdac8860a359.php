
<div class="modal fade bd-example-modal-lg" id="bahasa-form" tabindex="-1" role="dialog" aria-labelledby="mylargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content" style="background:#fff">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <div class="modal-body table-responsive">
                <div class="form-group<?php echo e($errors->has('bahasa') ? ' has-danger' : ''); ?>">
                    <label class="form-control-label" for="input-bahasa"><?php echo e(__('Tambah Bahasa')); ?></label>
                    <input type="text" name="tambah-bahasa" id="tambah-bahasa" class="form-control form-control-alternative<?php echo e($errors->has('bahasa') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Masukkan Bahasa Baru')); ?>" value="">

                    <?php if($errors->has('bahasa')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('bahasa')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="d-flex justify-content-center">
                    <button type="button" class="pilihBook btn btn-success" id="tambahBahasa" onclick="tambahBahasa()" data-dismiss="modal">Tambah</button>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="modal fade bd-example-modal-lg" id="kategori-form" tabindex="-1" role="dialog" aria-labelledby="mylargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content" style="background:#fff">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <div class="modal-body table-responsive">
                <div class="form-group<?php echo e($errors->has('kategori') ? ' has-danger' : ''); ?>">
                    <label class="form-control-label" for="input-kategori"><?php echo e(__('Tambah kategori')); ?></label>
                    <input type="text" name="tambah-kategori" id="tambah-kategori" class="form-control form-control-alternative<?php echo e($errors->has('kategori') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Masukkan kategori Baru')); ?>" value="">

                    <?php if($errors->has('kategori')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('kategori')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="d-flex justify-content-center">
                    <button type="button" class="pilihBook btn btn-success" id="tambahKategori" onclick="tambahKategori()" data-dismiss="modal">Tambah</button>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="modal fade bd-example-modal-lg" id="akses-form" tabindex="-1" role="dialog" aria-labelledby="mylargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content" style="background:#fff">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <div class="modal-body table-responsive">
                <div class="form-group<?php echo e($errors->has('akses') ? ' has-danger' : ''); ?>">
                    <label class="form-control-label" for="input-akses"><?php echo e(__('Tambah Akses')); ?></label>
                    <input type="text" name="tambah-akses" id="tambah-akses" class="form-control form-control-alternative<?php echo e($errors->has('akses') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Masukkan Akses Baru')); ?>" value="">

                    <?php if($errors->has('akses')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('akses')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="d-flex justify-content-center">
                    <button type="button" class="pilihBook btn btn-success" id="tambahAkses" onclick="tambahAkses()" data-dismiss="modal">Tambah</button>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="modal fade bd-example-modal-lg" id="lokasi-form" tabindex="-1" role="dialog" aria-labelledby="mylargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content" style="background:#fff">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <div class="modal-body table-responsive">
                <div class="form-group<?php echo e($errors->has('lokasi') ? ' has-danger' : ''); ?>">
                    <label class="form-control-label" for="input-lokasi"><?php echo e(__('Tambah Lokasi')); ?></label>
                    <input type="text" name="tambah-lokasi" id="tambah-lokasi" class="form-control form-control-alternative<?php echo e($errors->has('lokasi') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Masukkan Lokasi Baru')); ?>" value="">

                    <?php if($errors->has('lokasi')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('lokasi')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="d-flex justify-content-center">
                    <button type="button" class="pilihBook btn btn-success" id="tambahLokasi" onclick="tambahLokasi()" data-dismiss="modal">Tambah</button>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="modal fade bd-example-modal-lg" id="klasifikasi_buku-form" tabindex="-1" role="dialog" aria-labelledby="mylargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content" style="background:#fff">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <div class="modal-body table-responsive">
                <div class="form-group<?php echo e($errors->has('klasifikasi_buku') ? ' has-danger' : ''); ?>">
                    <label class="form-control-label" for="input-klasifikasi_buku"><?php echo e(__('Tambah Klasifikasi Buku')); ?></label>
                    <input type="text" name="tambah-klasifikasi_buku" id="tambah-klasifikasi_buku" class="form-control form-control-alternative<?php echo e($errors->has('klasifikasi_buku') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Masukkan Klasifikasi Buku Baru')); ?>" value="">

                    <?php if($errors->has('klasifikasi_buku')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('klasifikasi_buku')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="d-flex justify-content-center">
                    <button type="button" class="pilihBook btn btn-success" id="tambahKlasifikasiBuku" onclick="tambahKlasifikasiBuku()" data-dismiss="modal">Tambah</button>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="modal fade bd-example-modal-lg" id="subjek_buku-form" tabindex="-1" role="dialog" aria-labelledby="mylargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content" style="background:#fff">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <div class="modal-body table-responsive">
                <div class="form-group<?php echo e($errors->has('subjek_buku') ? ' has-danger' : ''); ?>">
                    <label class="form-control-label" for="input-subjek_buku"><?php echo e(__('Tambah Subjek Buku')); ?></label>
                    <input type="text" name="tambah-subjek_buku" id="tambah-subjek_buku" class="form-control form-control-alternative<?php echo e($errors->has('subjek_buku') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Masukkan Subjek Buku Baru')); ?>" value="">

                    <?php if($errors->has('subjek_buku')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('subjek_buku')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="d-flex justify-content-center">
                    <button type="button" class="pilihBook btn btn-success" id="tambahSubjekBuku" onclick="tambahSubjekBuku()" data-dismiss="modal">Tambah</button>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="modal fade bd-example-modal-lg" id="karya_tulis-form" tabindex="-1" role="dialog" aria-labelledby="mylargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content" style="background:#fff">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <div class="modal-body table-responsive">
                <div class="form-group<?php echo e($errors->has('karya_tulis') ? ' has-danger' : ''); ?>">
                    <label class="form-control-label" for="input-karya_tulis"><?php echo e(__('Tambah Bentuk Karya Tulis')); ?></label>
                    <input type="text" name="tambah-karya_tulis" id="tambah-karya_tulis" class="form-control form-control-alternative<?php echo e($errors->has('karya_tulis') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Masukkan Bentuk Karya Tulis Baru')); ?>" value="">

                    <?php if($errors->has('karya_tulis')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('karya_tulis')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="d-flex justify-content-center">
                    <button type="button" class="pilihBook btn btn-success" id="tambahKaryaTulis" onclick="tambahKaryaTulis()" data-dismiss="modal">Tambah</button>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="modal fade bd-example-modal-lg" id="jenis_buku-form" tabindex="-1" role="dialog" aria-labelledby="mylargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content" style="background:#fff">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <div class="modal-body table-responsive">
                <div class="form-group<?php echo e($errors->has('jenis_buku') ? ' has-danger' : ''); ?>">
                    <label class="form-control-label" for="input-jenis_buku"><?php echo e(__('Tambah Jenis Buku')); ?></label>
                    <input type="text" name="tambah-jenis_buku" id="tambah-jenis_buku" class="form-control form-control-alternative<?php echo e($errors->has('jenis_buku') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Masukkan Jenis Buku Baru')); ?>" value="">

                    <?php if($errors->has('jenis_buku')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('jenis_buku')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="d-flex justify-content-center">
                    <button type="button" class="pilihBook btn btn-success" id="tambahJenisBuku" onclick="tambahJenisBuku()" data-dismiss="modal">Tambah</button>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="modal fade bd-example-modal-lg" id="author-form" tabindex="-1" role="dialog" aria-labelledby="mylargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content" style="background:#fff">
            <div class="modal-header">
                    <h5>Tambah Pengarang</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <div class="modal-body table-responsive">
                <div class="form-group<?php echo e($errors->has('author') ? ' has-danger' : ''); ?>">
                    <label class="form-control-label" for="input-author"><?php echo e(__('Nama Pengarang')); ?></label>
                    <input type="text" name="tambah-author" id="tambah-author" class="form-control form-control-alternative<?php echo e($errors->has('author') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Masukkan Nama Pengarang Baru')); ?>" value="">

                    <?php if($errors->has('author')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('author')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label class="form-control-label"><?php echo e(__('Status Pengarang')); ?></label>
                    <div class="d-flex pt-2">
                        <select class="form-control" name="author-status" id="author-status">
                            <option value="Primary">Primary</option>
                            <option value="Additional">Additional</option>
                        </select>
                    </div>
                </div>
                <div class="d-flex justify-content-center">
                    <button type="button" class="pilihBook btn btn-success" id="tambahAuthor" onclick="tambahAuthor()" data-dismiss="modal">Tambah</button>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="modal fade bd-example-modal-lg" id="sumber-form" tabindex="-1" role="dialog" aria-labelledby="mylargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content" style="background:#fff">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <div class="modal-body table-responsive">
                <div class="form-group<?php echo e($errors->has('sumber') ? ' has-danger' : ''); ?>">
                    <label class="form-control-label" for="input-sumber"><?php echo e(__('Tambah Jenis Sumber')); ?></label>
                    <input type="text" name="tambah-sumber" id="tambah-sumber" class="form-control form-control-alternative<?php echo e($errors->has('sumber') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Masukkan Jenis Sumber Baru')); ?>" value="">

                    <?php if($errors->has('sumber')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('sumber')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="d-flex justify-content-center">
                    <button type="button" class="pilihBook btn btn-success" id="tambahSumber" onclick="tambahSumber()" data-dismiss="modal">Tambah</button>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="modal fade bd-example-modal-lg" id="currency-form" tabindex="-1" role="dialog" aria-labelledby="mylargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content" style="background:#fff">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <div class="modal-body table-responsive">
                <div class="form-group<?php echo e($errors->has('code') ? ' has-danger' : ''); ?>">
                    <label class="form-control-label" for="input-code"><?php echo e(__('Kode Mata Uang (ISO Currency Codes)')); ?></label>
                    <input type="text" name="tambah-code" id="tambah-code" class="form-control form-control-alternative<?php echo e($errors->has('code') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Masukkan Kode Mata Uang')); ?>" value="">

                    <?php if($errors->has('code')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('code')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>

                <div class="form-group<?php echo e($errors->has('currency') ? ' has-danger' : ''); ?>">
                    <label class="form-control-label pt-4" for="input-currency"><?php echo e(__('Mata Uang')); ?></label>
                    <input type="text" name="tambah-currency" id="tambah-currency" class="form-control form-control-alternative<?php echo e($errors->has('currency') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Masukkan Mata Uang Baru')); ?>" value="">

                    <?php if($errors->has('currency')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('currency')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>

                <div class="d-flex justify-content-center pt-3">
                    <button type="button" class="pilihBook btn btn-success" id="tambahCurrency" onclick="tambahCurrency()" data-dismiss="modal">Tambah</button>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH D:\repolib\resources\views/bibliografi/books/addSection.blade.php ENDPATH**/ ?>